
# Site Messenger (CEO Outreach) — Streamlit

Purpose-built for **contract/construction work sites** so leadership can message **Site Advisors, Site Managers, and crews**
across **specific sites, companies, and regions**. Supports **multi-filter targeting** with **AND/OR** logic, deduping, and
Email + WhatsApp sending.

## Highlights
- Upload CSV with columns: `name,email,phone,company,region,site,role` (+ optional `notes`).
- Filter by **Company**, **Region**, **Site**, **Role** (multi-select each).
- Choose **Match Logic**: **ALL (AND)** or **ANY (OR)** across filters.
- Quick chips for common audiences (e.g., "All Site Managers @ selected sites").
- Deduplicate by email/phone so nobody is messaged twice.
- Personalize messages with `{name}`, `{role}`, `{site}`, `{company}`, `{region}`.
- Dry-run preview + downloadable **recipient list** and **send report**.
- Email via SMTP, WhatsApp via Twilio (one-by-one sending).

## Quick Start
1) Create a venv & install:
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate
pip install -r requirements.txt
```

2) Configure secrets:
- Copy `.env.example` → `.env` and fill in **SMTP** and/or **Twilio** values (see file for details).

3) Run:
```bash
streamlit run app.py
```

4) In the app:
- Load `sample_contacts.csv` (or your own).
- Select filters & **Match Logic** (ALL vs ANY).
- Pick channels (Email/WhatsApp); do a **Dry-run** first.
- Review the preview, then send. Export the send report for records.

### CSV Schema
Required columns:
- **name** — Full name
- **email** — Email (optional if WhatsApp-only)
- **phone** — E.164 (e.g., +19173913382) for WhatsApp
- **company** — e.g., "Acme Build Co"
- **region** — e.g., "NYC", "Northeast"
- **site** — Site name / project, e.g., "Hudson Yards — Tower B"
- **role** — e.g., "Site Advisor", "Site Manager", "Foreman", "Estimator"

Optional: **notes**

### Compliance
- Ensure you have consent and follow anti-spam laws.
- Provide opt-out language (toggle provided in app).
- Consider using a sending domain with proper SPF/DKIM/DMARC.
