
import os, time, smtplib, ssl, re
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import streamlit as st
import pandas as pd
from dotenv import load_dotenv

load_dotenv()

# Optional Twilio
TWILIO_AVAILABLE = True
try:
    from twilio.rest import Client as TwilioClient
except Exception:
    TWILIO_AVAILABLE = False

st.set_page_config(page_title="Site Messenger — Outreach", page_icon="🏗️", layout="wide")
st.title("🏗️ Site Messenger — Outreach")
st.caption("Target Site Advisors, Site Managers, and more across companies, regions, and job sites.")

with st.expander("1) Upload Contacts CSV or Use Sample", expanded=True):
    uploaded = st.file_uploader("Upload CSV with columns: name,email,phone,company,region,site,role[,notes]", type=["csv"])
    if uploaded is not None:
        df = pd.read_csv(uploaded)
    else:
        st.info("No file uploaded — using provided sample_contacts.csv.")
        sample_path = os.path.join(os.path.dirname(__file__), "sample_contacts.csv")
        df = pd.read_csv(sample_path)

    required = ["name","email","phone","company","region","site","role"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        st.error(f"Missing required columns: {missing}")
        st.stop()

    for c in df.columns:
        df[c] = df[c].astype(str).str.strip()

    st.dataframe(df, use_container_width=True)

with st.expander("2) Choose Audience & Match Logic", expanded=True):
    # Build selectors
    companies = sorted(df["company"].dropna().unique().tolist())
    regions = sorted(df["region"].dropna().unique().tolist())
    sites = sorted(df["site"].dropna().unique().tolist())
    roles = sorted(df["role"].dropna().unique().tolist())

    sel_companies = st.multiselect("Companies", companies)
    sel_regions = st.multiselect("Regions", regions)
    sel_sites = st.multiselect("Sites", sites)
    # Provide handy quick chips for typical roles
    default_roles = [r for r in roles if r.lower() in {"site advisor","site manager"}]
    sel_roles = st.multiselect("Roles", roles, default=default_roles or roles)

    match_logic = st.radio("Match Logic (across filters)", ["ALL (AND)", "ANY (OR)"], horizontal=True, index=0)

    # Build mask
    masks = []
    if sel_companies:
        masks.append(df["company"].isin(sel_companies))
    if sel_regions:
        masks.append(df["region"].isin(sel_regions))
    if sel_sites:
        masks.append(df["site"].isin(sel_sites))
    if sel_roles:
        masks.append(df["role"].isin(sel_roles))

    if masks:
        if match_logic.startswith("ALL"):
            from functools import reduce
            import operator
            filt_mask = reduce(operator.and_, masks)
        else:
            from functools import reduce
            import operator
            filt_mask = reduce(operator.or_, masks)
        targeted = df[filt_mask].copy()
    else:
        targeted = df.copy()

    # Dedupe by email/phone
    targeted["key"] = targeted.apply(lambda r: (r.get("email","").lower(), r.get("phone","")), axis=1)
    before = len(targeted)
    targeted = targeted.drop_duplicates(subset=["key"]).drop(columns=["key"])
    after = len(targeted)
    deduped_msg = f" (deduped {before-after})" if after < before else ""

    st.write(f"**Targeted recipients:** {len(targeted)}{deduped_msg}")
    st.dataframe(targeted, use_container_width=True)

    st.download_button(
        "Download targeted list (CSV)",
        data=targeted.to_csv(index=False).encode("utf-8"),
        file_name="targeted_recipients.csv",
        mime="text/csv",
    )

with st.expander("3) Compose Message", expanded=True):
    channels = st.multiselect("Channels", ["Email", "WhatsApp"], default=["Email"])
    subject = st.text_input("Email Subject", value="Update for {site} — from the CEO")
    message = st.text_area(
        "Message (use placeholders: {name}, {role}, {site}, {company}, {region})",
        height=200,
        value=(
            "Hi {name},\n\n"
            "I’m reaching out regarding {site}. Please share a quick status update and any blockers.\n\n"
            "Appreciate your leadership on site.\n\n"
            "— CEO"
        )
    )
    add_footer = st.checkbox("Append opt-out footer", value=True)
    footer = "\n\n—\nIf you prefer not to receive broadcast updates, reply STOP."

def format_placeholders(txt: str, row: pd.Series) -> str:
    safe = txt
    for key in ["name","role","site","company","region"]:
        safe = safe.replace("{" + key + "}", str(row.get(key, "")))
    return safe

# SMTP
import ssl
SMTP_HOST = os.getenv("SMTP_HOST", "")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587") or "587")
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASS = os.getenv("SMTP_PASS", "")
SMTP_FROM = os.getenv("SMTP_FROM", SMTP_USER or "")

def send_email(to_addr: str, subject: str, body: str) -> tuple[bool, str]:
    if not (SMTP_HOST and SMTP_PORT and SMTP_USER and SMTP_PASS and SMTP_FROM):
        return False, "SMTP configuration missing."
    try:
        msg = MIMEMultipart()
        msg["From"] = SMTP_FROM
        msg["To"] = to_addr
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain", "utf-8"))

        context = ssl.create_default_context()
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls(context=context)
            server.login(SMTP_USER, SMTP_PASS)
            server.send_message(msg)
        return True, "sent"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

# Twilio
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")
TWILIO_WHATSAPP_FROM = os.getenv("TWILIO_WHATSAPP_FROM", "")

def looks_like_e164(phone: str) -> bool:
    return bool(re.fullmatch(r"\+[1-9]\d{6,14}", phone or ""))

def send_whatsapp(to_phone: str, body: str) -> tuple[bool, str]:
    if not TWILIO_AVAILABLE:
        return False, "Twilio SDK not installed."
    if not (TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN and TWILIO_WHATSAPP_FROM):
        return False, "Twilio configuration missing."
    if not looks_like_e164(to_phone):
        return False, "Phone must be E.164 format (+countrycode...)."
    try:
        client = TwilioClient(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        msg = client.messages.create(
            from_=TWILIO_WHATSAPP_FROM,
            to=f"whatsapp:{to_phone}" if not to_phone.startswith("whatsapp:") else to_phone,
            body=body
        )
        return True, f"queued: {msg.sid}"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

with st.expander("4) Dry Run & Send", expanded=True):
    dry_run = st.checkbox("Dry-run (no actual sends)", value=True)
    delay = st.number_input("Delay between messages (seconds)", min_value=0.0, max_value=10.0, value=0.5, step=0.5)

    # Preview
    if len(df):
        sample = df.iloc[0]
        subj0 = format_placeholders(subject, sample)
        msg0 = format_placeholders(message, sample) + (footer if add_footer else "")
        st.subheader("Preview (example)")
        st.code(f"Subject: {subj0}\n\n{msg0}")

    go = st.button("Send to Targeted Recipients")

    if go:
        if len(targeted) == 0:
            st.warning("No targeted recipients.")
            st.stop()
        if not channels:
            st.warning("Select at least one channel.")
            st.stop()

        results = []
        for _, row in targeted.iterrows():
            per_subject = format_placeholders(subject, row)
            per_message = format_placeholders(message, row) + (footer if add_footer else "")

            status_email = "skipped"
            status_wa = "skipped"

            if dry_run:
                if "Email" in channels and row.get("email"):
                    status_email = "DRY-RUN"
                if "WhatsApp" in channels and row.get("phone"):
                    status_wa = "DRY-RUN"
            else:
                if "Email" in channels and str(row.get("email", "")).strip():
                    ok, info = send_email(str(row["email"]).strip(), per_subject, per_message)
                    status_email = "OK" if ok else f"ERR: {info}"
                if "WhatsApp" in channels and str(row.get("phone", "")).strip():
                    ok, info = send_whatsapp(str(row["phone"]).strip(), per_message)
                    status_wa = "OK" if ok else f"ERR: {info}"
                time.sleep(delay)

            results.append({
                "name": row["name"],
                "email": row["email"],
                "phone": row["phone"],
                "company": row["company"],
                "region": row["region"],
                "site": row["site"],
                "role": row["role"],
                "email_status": status_email,
                "whatsapp_status": status_wa,
            })

        res_df = pd.DataFrame(results)
        st.success("Done. See results below.")
        st.dataframe(res_df, use_container_width=True)
        st.download_button(
            "Download send report (CSV)",
            data=res_df.to_csv(index=False).encode("utf-8"),
            file_name="send_report.csv",
            mime="text/csv",
        )

st.markdown("---")
st.caption("Built for construction/contract site outreach. Email via SMTP, WhatsApp via Twilio.")
